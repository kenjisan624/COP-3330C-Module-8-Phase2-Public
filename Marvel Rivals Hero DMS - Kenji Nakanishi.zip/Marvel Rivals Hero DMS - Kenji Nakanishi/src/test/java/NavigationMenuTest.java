import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.io.*;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

import java.util.Map;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;



public class NavigationMenuTest {
    // Setting up some helpers that will allow us to access private members
    private static void setPrivateField(Object target, String fieldName, Object value)
    {
        try {
            Field f = target.getClass().getDeclaredField(fieldName);
            f.setAccessible(true);
            f.set(target,value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    // Allowing access to NavigationMenu and read / return to be able to test our sample data
    @SuppressWarnings("unchecked")
    private static Map<String, Hero> getHeroMap(NavigationMenu nav) {
        try {
            Field f = nav.getClass().getDeclaredField("heroRecords");
            f.setAccessible(true);
            return (Map<String, Hero>) f.get(nav);
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    // Simulation for user input in the testing environment
    private static void setScanner (NavigationMenu nav, String lines){
        ByteArrayInputStream in = new ByteArrayInputStream(lines.getBytes(StandardCharsets.UTF_8));
        setPrivateField(nav, "In", new Scanner(in));
    }
    // If needed for temporary file creation
    private static void setSAVEFILE(NavigationMenu nav, Path path) {
        setPrivateField(nav, "SAVE_FILE", path);
    }
    // This will allow us to type faster in the testing environment; intead of adding new Hero each time
    // we want to test a hero, we can just type the values directly
    private static Hero hero(String id, String name, int hp, int spd, int ult, String role, double wr){
        return new Hero(id, name, hp, spd, ult, role, wr);
    }



    @org.junit.jupiter.api.Test
    @DisplayName("Creating of hero test")
    void createMHero_Test() throws Exception{
        NavigationMenu nav = new NavigationMenu();

        setScanner(nav, String.join("\n",
                "123",
                "Rocket Raccoon",
                "250",
                "7",
                "1500",
                "Strategist",
                "55.5"
                ) + "\n");

                boolean approvedSuccessfully = nav.CreateMHero();
                assertTrue(approvedSuccessfully, "Create Marvel Hero must return true for valid input!");

                Map<String, Hero> map = getHeroMap(nav);
                assertTrue(map.containsKey("123"));
                Hero h = map.get("123");
                assertEquals("Rocket Raccoon",h.getHeroName());
                assertEquals(250,h.getHealthPoint());
                assertEquals(7,h.getMovementSpeed());
                assertEquals(1500,h.getUltDamage());
                assertEquals("Strategist",h.getHeroRole());
                assertEquals(55.5,h.getWinRate(),1e-2);
    }

    // This portion of the test will simulate multiple input correct and wrong as per our
    // Implementation plan, we will try to add information that could potentially broke the code
    @ParameterizedTest
    @CsvSource({
            // id, name, hp, speed, ult, role, winRate, expectedSuccess
            "012, Invisible Woman, 300, 6, 9999, Duelist, 61.80, true", // Correct input formatting!
            "1-2, Jeffy the Landy Sharky, -90, 0.01, -3, scientist, 90.23, false", // Wrong:identityID, Name, and Role
            "A90, Blade Man, 9999, -100, ao3, politician, 0.8790, false", // Wrong: identity ID and Role
            "*1*, Dead Pool, 777, 99, 0,Strategist, 60.09,false", // Wrong: identity ID
            "Wa8, Ant Man, 450, 9, 1200, Strategis, 46.49, false" // Wrong: identity ID and Role
    })

    @DisplayName("Creating MULTIPLE Heroes test")
    void createMHero_multiple(
            String id,
            String name,
            String hp,
            String speed,
            String ult,
            String role,
            String winRate,
            boolean expectedSuccess) {
        NavigationMenu nav = new NavigationMenu();

        String input = String.join("\n", id, name, hp, speed, ult, role, winRate) + "\n";
        setScanner(nav, input);

        boolean success = nav.CreateMHero();
        assertEquals(expectedSuccess, success);

        if (!expectedSuccess) {
            assertFalse(getHeroMap(nav).containsKey(id));
        }
    }



    // Removing an artificially added hero id
    @org.junit.jupiter.api.Test
    @DisplayName("Removing by ID test")
    void removingByid() {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        map.put("123",hero("123","Doctor Doom",900,9,9999,"Vanguard",99.9));

        setScanner(nav, "123\ny\n");

        boolean removed = nav.RemovingByid();
        assertTrue(removed);
        assertFalse(map.containsKey("123"), "Hero removed from the map");
    }

    //In case the user decided to cancel the removal, we want to make sure the hero is not removed
    @org.junit.jupiter.api.Test
    @DisplayName("Removing by ID & user cancels 'N'")
    void removingByidCancelByUser() {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        map.put("234", hero("234","Green Goblin", 800, 7, 4500,"Vanguard",67.90));

        setScanner(nav, "234\nn\n");

        boolean removed = nav.RemovingByid();
        assertFalse(removed);
        assertTrue(map.containsKey("234"), "Hero should not be removed after the cancel command");
    }

    // When user wants to erase an ID that is not stored, we will add an artificial data and then
    // scan a number ID that does not exist
    @org.junit.jupiter.api.Test
    @DisplayName("Removing By ID & no ID identified")
    void removingByidNoID() {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        map.put("345", hero("345","The Dormamu", 900, 6, 9998,"Vanguard",90.98));

        setScanner(nav, "543\n");

        boolean removed = nav.RemovingByid();
        assertFalse(removed);
        assertEquals(1, map.size(), "Hero list must have not change");
        assertTrue(map.containsKey("345"), " ID No found");
    }

    // Try to erase from an empty list will return ERROR: Heroes list is Empty!
    @org.junit.jupiter.api.Test
    @DisplayName("Removing by ID but Empty list")
    void  removingByidEmptyList() {
        NavigationMenu nav = new NavigationMenu();

        boolean removed = nav.RemovingByid();
        assertFalse(removed);
    }

    //Imagine user types another characters when asking for confirmation.
    // after user types Y to erase, confirm data has been erased.
    @org.junit.jupiter.api.Test
    @DisplayName("Removing BY ID; invalid confirm and then Y")
    void removingByidInvalidConfirmAndThenY() {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        map.put("456", hero("456","The Thanos",900,9,9999,"Vanguard",99.99));

        setScanner(nav, "456\nhehehe?\ny\n");

        boolean removed = nav.RemovingByid();
        assertTrue(removed);
        assertFalse(map.containsKey("456"), " Identity ID has been removed correct!");
    }

    // Similar to create a marvel rival hero;
    @org.junit.jupiter.api.Test
    @DisplayName("Updating Hero test")
    void updateMRHero() {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        map.put("456", hero("456","The Thanos",900,9,9999,"Vanguard",99.99));

        setScanner(nav, String.join("\n",
                "456",
                "y",
                "Thanitos Monster Man",
                "899",
                "8",
                "9998",
                "Vanguard",
                "98.99") + "\n");

        boolean ok = nav.UpdateMRHero();
        assertTrue(ok);

        Hero h = map.get("456");
        assertEquals("Thanitos Monster Man", h.getHeroName());
        assertEquals(899,h.getHealthPoint());
        assertEquals(8,h.getMovementSpeed());
        assertEquals(9998,h.getUltDamage());
        assertEquals("Vanguard",h.getHeroRole());
        assertEquals(98.99,h.getWinRate(), 1e-2);

    }

    // created a Parameterized Test as per Phase 2 testing indicates tried different inputs to try breaking the code:
    @ParameterizedTest
    @CsvSource(
            value = {
            // id, confirmation, name, hp, speed, ult, role, winRate, expectedSuccess
            "456,y,Invisible Woman, null,null,null, Scientist,null , false",
            "456,y,Thanos Kid,      null,null,null, Duelist,79.89,true",
            "456,y,Captain Marvel,  null,null,null,Strategist,75.89, true"
    },
            nullValues = {"null","NULL"}
    )
    void updateMRHeroInvalidInputs(
            String Id,
            String confirmation,
            String NewName,
            String NewHp,
            String NewSpeed,
            String NewUlt,
            String NewRole,
            String NewWinRate,
            boolean expectedSuccess
    ) {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        if ("456".equals(Id)) {
        map.put("456", hero("456","The Thanos",900,9,9999,"Vanguard",90.98));
        }

        String input = String.join("\n",
                Id,
                confirmation,
                NewName == null ? "" : NewName,
                NewHp == null ? "" : NewHp,
                NewSpeed  == null ? "" : NewSpeed,
                NewUlt  == null ? "" : NewUlt,
                NewRole   == null ? "" : NewRole,
                NewWinRate == null ? "" : NewWinRate
                ) + "\n";

        setScanner(nav, input);

        boolean success = nav.UpdateMRHero();
        assertEquals(expectedSuccess, success);
    }


    // Here I am adding a sample data from possibly future heroes releases!
    // to later print them out
    @org.junit.jupiter.api.Test
    @DisplayName("Display All Data test")
    void displayAllData() {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        map.put("678", hero("678","Norman Osborn", 450,6,1900,"Duelist",49.00));
        map.put("789", hero("789","Doctor Octupus ", 350,9,4900,"Duelist",61.40));
        map.put("890", hero("890","The Sandman", 750,6,7100,"Vanguard",69.00));

        var list = nav.DisplayAllData();
        assertEquals(3, list.size());
        assertEquals("678", list.get(0).getIdentityHeroID());
        assertEquals("789", list.get(1).getIdentityHeroID());
        assertEquals("890", list.get(2).getIdentityHeroID());

    }

    // Add an artificial hero record to later find it and print it out based on identity ID
    @org.junit.jupiter.api.Test
    @DisplayName("Search by ID test")
    void searchHeroByID() {
        NavigationMenu nav = new NavigationMenu();
        Map<String, Hero> map = getHeroMap(nav);
        map.put("567", hero("567","Madame Masque", 250, 6,1750,"Strategist",61.90));

        setScanner(nav, "567\n");
        Hero found = nav.SearchHeroByID();
        assertNotNull(found);
        assertEquals("Madame Masque", found.getHeroName());
    }

    // I am creating a temp file titled Season1WinRate and printed out what has been added to the testing
    // environment; so the user can see what has been added.
    @org.junit.jupiter.api.Test
    @DisplayName("Load from CSV file test")
    void loadFromTxtFile(@TempDir Path temp) throws Exception {
        Path file = temp.resolve("Season1WinRate.csv");

        Files.writeString(
                file,
                "001-Adam Warlock-250-6-4700-Strategist-50.29\n" +
                "002-Angela-450-6-3100-Vanguard-53.98\n" +
                "003-Black Panther-275-7-3300-Duelist-54.86\n" +
                "004-Black Widow-250-6-2800-Duelist-42.37\n" +
                "005-Blade-350-6-2800-Duelist-48.92\n",
                StandardCharsets.UTF_8
        );

        NavigationMenu nav = new NavigationMenu();

        setScanner(nav, file.toString()+ "\n");

        nav.LoadFromTxtFile();

        Map<String, Hero> map = getHeroMap(nav);
        assertEquals(5, map.size());
        assertTrue(map.containsKey("001"));
        assertTrue(map.containsKey("002"));
        assertTrue(map.containsKey("003"));
        assertTrue(map.containsKey("004"));
        assertTrue(map.containsKey("005"));


        System.out.println("Heroes loaded in the Test from CSV file: \n");
        for (Hero hero : map.values()) {
            System.out.println(hero);
        }
    }

    // Based on the calculations values provided by Marvel Rivals.com
    // My custom method creates a PDF file on the user folder
    // as a test method, this will simulate the creation of the file on the folder
    @org.junit.jupiter.api.Test
    @DisplayName("Generate report test")
    void generateWinRateReport(@TempDir Path temp) throws Exception {
    NavigationMenu nav = new NavigationMenu();
    Map<String, Hero> map = getHeroMap(nav);
        map.put("001", hero("001", "Adam Warlock", 250,6,4700,"Strategist",50.29));
        map.put("002", hero("002", "Angela", 450,6,3100,"Vanguard",53.98));

        String oldUserDir = System.getProperty("user.dir");
        try {
            System.setProperty("user.dir", temp.toString());

            Path pdf = nav.GenerateWinRateReport();

            assertNotNull(pdf, "Must return PDF path");
            assertTrue(Files.exists(pdf), "PDF exists");
        } finally{
            System.setProperty("user.dir", oldUserDir);
        }
    }
}
/*
Professor: Lisa Macon
Name: Kenji Nakanishi
Course: CEN 3024C - Software Development-I CRN:14877
Date: 10/23/2025

Purpose of the DMS: For this part of the course, Our task is to create a Data Management System within the Phase 1
Where Logic and Input Validation is the key; I have decided to create a DMS for my favorite game titled Marvel Rivals
This main method will connect to the NavigationMenu and inside we have CRUD methods + Custom Method which will create a PDF
document with the Character Win Rate. This Win Rate is calculated by dividing (won matches / matches played) * 100.
The Win Rate calculation will be done by Marvel Rivals and I will use this data to create the PDF file on the user folder.

Phase 2: Software Testing !
 */
public class MarvelRivalsApp {
    public static void main(String[] args) {
       new NavigationMenu().start();
    }
}